package com.example.manishgupta.tcpclient;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

public class TCPClient extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tcpclient);
    }

    public void onButtonClick (View v) {


        EditText EditTextIP = (EditText)findViewById(R.id.editTextIP);

        EditText EditTextPort = (EditText)findViewById(R.id.editTextPort);

        EditText EditTextCommand = (EditText)findViewById(R.id.editTextCommand);

        String ip = EditTextIP.getText().toString();
        int port = 80;
        String porttext = EditTextPort.getText().toString();
        if(porttext!="" && !porttext.isEmpty()) {
            port = Integer.parseInt(porttext);
        }
        String command = EditTextCommand.getText().toString().trim();

        TextView displayResult = (TextView)findViewById(R.id.textViewResult);
        displayResult.setText("Please wait...");

        SendCommand sendCommand = new SendCommand(ip,port,command);
        sendCommand.execute();


       Log.d("TAG", "Send Data");
    }

    public class SendCommand extends AsyncTask<Void, Void, Void>{

        String ServerIP;
        int ServerPort;
        String response;
        String command;
        byte[] inData;
        BufferedReader inBuf = null;
        PrintWriter pw = null;
        StringBuilder sb = new StringBuilder();
        String data;
        String displayData;


        SendCommand(String ip, int port, String msg){

            ServerIP = ip;
            ServerPort = port;
            command = msg;
        }

        @Override
        protected Void doInBackground(Void... params) {

            Socket socket = null;



            try{
                socket = new Socket(ServerIP,ServerPort);

                pw = new PrintWriter(socket.getOutputStream(),true);

                if(command != null){
                    pw.write(command+"\r\n");
                    pw.flush();


                }

                    inBuf = new BufferedReader(new InputStreamReader(socket.getInputStream()));


                while(true) {   //read in loop untill VC! is detected

                    data = inBuf.readLine(); //response

                    if(data==null)break; //something wrong on socket

                    sb.append(data);
                    sb.append("\r\n");

                    displayData = sb.toString(); //just to display response

                    TCPClient.this.runOnUiThread(new Runnable() {

                        @Override
                        public void run() {
                            TextView displayResult = (TextView) findViewById(R.id.textViewResult);
                            displayResult.setText(displayData);

                        }
                    });


                    if(data!=null && data.contains("VC!")) //we reached at end
                        break;


                }

             /*   while ((data = inBuf.readLine()) != null)
                {
                    sb.append(data);

                }

                outData = sb.toString();
                */

                //inBuf.close();
                //socket.close();

                //Log.d("TCP_CLIENT",data);


            } catch (UnknownHostException e) {

                e.printStackTrace();
                response = "UnknownHostException: " + e.toString();

            } catch (IOException e) {

                e.printStackTrace();
                response = "IOException: " + e.toString();
            }finally {
                Log.d("TCP_CLIENT","finally called");
                if(socket !=null){
                    try {
                        socket.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                if(pw != null){

                        pw.close();

                }
                if(inBuf !=null){

                    try {
                        inBuf.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                }


            }


            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {

            TextView displayResult = (TextView)findViewById(R.id.textViewResult);
          //  if(outData != null)
            //    displayResult.setText(outData);
           // Toast.makeText(getApplicationContext(),outData,Toast.LENGTH_LONG).show();
           /* else */ if(response !=null)
                displayResult.setText(response);
            //Toast.makeText(getApplicationContext(),response,Toast.LENGTH_LONG).show();
            super.onPostExecute(aVoid);
        }
    }


    @Override

    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_tcpclient, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
